function OpenForm (id) {
    if (id == 1) {
        document.getElementById('modal1').style.display = "block";
    document.body.style.overflow = "hidden";
    } else if (id==2) {
        document.getElementById('modal2').style.display = "block";
        document.body.style.overflow = "hidden";
    }
    
}

function CloseForm (name) {
    document.getElementById(name).style.display = "none";
    document.body.style.overflow = "visible";
}

function CheckPass () {
    var obj = document.getElementById('passSubmit');
    if (document.getElementById('formPass').value==document.getElementById('formPassSub').value) {
        obj.style.display = "block";
    } else {
        obj.style.display = "none";
    }
}

var i = 0;

function click123(){
    let imgs = ['img/1.png', 'img/2.png', 'img/3.png', 'img/4.png', 'img/5.png'];
    var img = document.getElementById("sliderImg");
   
    i++;
    img.src = imgs[i];

    if(i==4) {
        i = -1;
    }
}

function validate() {
    let name = document.forms["formAbout"]["name"].value;
    if (name=="") {
        alert("Введите имя!");
        return false;
    }

    let email = document.forms["formAbout"]["email"].value;
    if (email=="") {
        alert("Введите E-Mail!");
        return false;
    }

    let phone = document.forms["formAbout"]["phone"].value;
    if (phone=="") {
        alert("Введите телефон!");
        return false;
    }

    let problem = document.forms["formAbout"]["problem"].value;
    if (problem=="") {
        alert("Введите проблему!");
        return false;
    }
}