function showUserInfo(){
    if (getCookie('auth') == 1) {
        document.getElementById("regButton").style.display="none";
        document.getElementById("userWin").style.display="";
        document.getElementById("userLogin").innerHTML = '<p>Здраствуйте, ' + getCookie('username') + '!</p>';
    } else {
        document.getElementById("regButton").style.display="";
        document.getElementById("userWin").style.display="none";
    }
}

function setLogin() {
    document.cookie = "username=" + document.getElementById("formLogin").value + "; path=/;";
    document.cookie = "password=" + document.getElementById("formPass").value + "; path=/;";
    document.cookie = "auth=1";
    document.getElementById("registrationForm").style.display = "none";
}

function userLogOut() {
    alert("Прощайте," + getCookie('username') + "! Будем сильно скучать по вам!");
    deleteCookie('username');
    deleteCookie('password');
    deleteCookie('auth');
    document.getElementById("regButton").style.display="";
    document.getElementById("userWin").style.display="none";
}

//Функция поиска значения куки по ключу
function getCookie(name) {
	var matches = document.cookie.match(new RegExp("(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"));
	return matches ? decodeURIComponent(matches[1]) : undefined;
}

function setCookie(name,value) {
    document.cookie = encodeURIComponent(name) + "=" + encodeURIComponent(value) + ";path=/";
}

function deleteCookie(name) {
    document.cookie = encodeURIComponent(name) + "= 1; max-age=-1";
}
