var result = 0;
localStorage.setItem('result',result);
var new_result = 0;
var tryTest = 0;
localStorage.setItem('tryTest',tryTest);

function checkAnswer(object) {
    if (object.value=="true") {
        object.style.background="green";
        new_result ++;
    } 
    else {
        object.style.background="red";
        new_result --;
    }
}

function sumResult() {
    if (localStorage.getItem('tryTest') == 0) {
        tryTest ++;
        localStorage.setItem('tryTest',tryTest);
        document.getElementById('checkResult').innerHTML = "<p> Сейчас у вас " + new_result + " баллов!";
        localStorage.setItem('result', new_result);
    } else {
        tryTest ++;
        localStorage.setItem('tryTest',tryTest);
        
    }
}

function checkResults() {
    if (localStorage.getItem('tryTest') > 1) {
        document.getElementById('checkResult').innerHTML = "<p>В прошлый раз было</p>" + localStorage.getItem('result') + " баллов! Сейчас у вас " + new_result + " баллов!";
        localStorage.setItem('result', new_result);
        document.getElementById('quesWin').style.display = 'none';
    }
}



function again() {
    document.getElementById('quesWin').style.display = 'block';
}

